# HPE NetOps UI

A web-based chat and operations interface for the HPE Networking MCP Server. Connects Claude to your Mist, Central, GreenLake, ClearPass, Axis, and UXI platforms via a browser UI.

## Architecture

```
Browser
  ↕ HTTPS
Nginx (reverse proxy)
  ↕
React Frontend (port 3000)   Node.js Backend (port 3001)
  ↕ REST/SSE                   ↕ Anthropic API + MCP
                           hpe-networking-mcp (port 8000)
                               ↕
                 Mist | Central | GreenLake | ClearPass | Axis | UXI
```

## Quick Start (Local)

**1 — Prerequisites**
- Docker Desktop running
- `hpe-networking-mcp:latest` image already built (see main repo)

**2 — Configure**
```bash
cp .env.example .env
# Edit .env with your Anthropic API key and secrets path
```

**3 — Run**
```bash
docker compose up --build
```

Open http://localhost:3000

## Development (without Docker)

**Backend:**
```bash
cd backend
cp .env.example .env   # fill in values
npm install
npm run dev            # runs on port 3001
```

**Frontend:**
```bash
cd frontend
npm install
npm run dev            # runs on port 5173, proxies /api to 3001
```

## VM Deployment (Production)

### 1 — Provision a VM
- Ubuntu 22.04 LTS, 2 vCPU, 4GB RAM
- Open ports 22, 80, 443

### 2 — Install dependencies
```bash
# Docker
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker $USER

# Nginx
sudo apt install -y nginx certbot python3-certbot-nginx

# Node.js (for local dev only — not needed for Docker deploy)
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs
```

### 3 — Clone and configure
```bash
git clone https://github.com/nickshoe18/network-mcp-server.git ~/netops
cd ~/netops/netops-ui
cp .env.example .env
nano .env   # add ANTHROPIC_API_KEY and SECRETS_DIR
```

### 4 — Copy secrets
```bash
# Copy your hpe-networking-mcp secrets folder to the VM
scp -r ~/hpe-networking-mcp/secrets user@your-vm-ip:~/hpe-secrets
```

### 5 — Build and start
```bash
# Build the hpe-mcp image on the VM
git clone https://github.com/nowireless4u/hpe-networking-mcp.git ~/hpe-networking-mcp
cd ~/hpe-networking-mcp && docker build -t hpe-networking-mcp:latest .

# Start the full stack
cd ~/netops/netops-ui
docker compose up -d --build
```

### 6 — Configure Nginx + SSL
```bash
# Copy Nginx config
sudo cp nginx/netops.conf /etc/nginx/sites-available/netops
# Edit with your domain
sudo nano /etc/nginx/sites-available/netops

# Enable site
sudo ln -s /etc/nginx/sites-available/netops /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx

# Get SSL certificate (requires domain pointing to VM)
sudo certbot --nginx -d your-domain.com

# Auto-renewal
sudo systemctl enable certbot.timer
```

### 7 — (Optional) Restrict access
To limit to your team only, add to the Nginx config:
```nginx
allow YOUR_OFFICE_IP;
allow YOUR_VPN_IP;
deny all;
```

Or use Nginx Basic Auth:
```bash
sudo apt install apache2-utils
sudo htpasswd -c /etc/nginx/.htpasswd admin
```
Add to Nginx server block:
```nginx
auth_basic "HPE NetOps";
auth_basic_user_file /etc/nginx/.htpasswd;
```

## Security Notes

- Never expose the hpe-mcp container (port 8000) publicly — it has no auth
- Store `ANTHROPIC_API_KEY` only in `.env`, never in code
- Use IP allowlist or Basic Auth for team-internal deployments
- Use OAuth2/SSO (e.g. via Authelia or Cloudflare Access) for broader access
- Rate limiting is built into the backend (60 req/min per IP)

## Updating

```bash
cd ~/netops/netops-ui
git pull
docker compose down
docker compose up -d --build
```
