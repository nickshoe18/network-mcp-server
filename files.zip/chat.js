import { Router } from "express";
import Anthropic from "@anthropic-ai/sdk";

export const chatRouter = Router();

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
const MCP_URL = process.env.MCP_SERVER_URL || "http://hpe-mcp:8000/mcp";

// ── POST /api/chat ─────────────────────────────────────────────────────────────
// Body: { messages: [{role, content}], conversationId? }
// Response: SSE stream of text deltas and tool events
chatRouter.post("/", async (req, res) => {
  const { messages } = req.body;

  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({ error: "messages array required" });
  }

  // Set up SSE
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  res.flushHeaders();

  const send = (event, data) => {
    res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
  };

  try {
    // Stream response from Claude with MCP server connected
    const stream = await client.beta.messages.stream({
      model: "claude-sonnet-4-20250514",
      max_tokens: 4096,
      system: `You are a network operations assistant connected to the HPE Networking MCP server.
You have access to tools for Juniper Mist, Aruba Central, HPE GreenLake, ClearPass, Aruba Axis, and UXI.
Be concise and precise. Format data as markdown tables where helpful.
When calling tools, explain briefly what you're doing before the tool call.`,
      messages,
      mcp_servers: [{
        type: "url",
        url: MCP_URL,
        name: "hpe-networking-mcp",
      }],
      betas: ["mcp-client-2025-04-04"],
    });

    // Stream events to frontend
    stream.on("text", (text) => {
      send("text", { text });
    });

    stream.on("message_start", () => {
      send("start", { ts: Date.now() });
    });

    // Tool use events — send to UI so it can show "calling tool…"
    stream.on("content_block_start", (event) => {
      if (event.content_block?.type === "tool_use") {
        send("tool_start", { name: event.content_block.name });
      }
    });

    stream.on("content_block_stop", (event) => {
      if (event.content_block?.type === "tool_use") {
        send("tool_end", { name: event.content_block.name });
      }
    });

    const final = await stream.finalMessage();
    send("done", {
      usage: final.usage,
      stop_reason: final.stop_reason,
    });

  } catch (err) {
    console.error("Chat error:", err.message);
    send("error", { message: err.message || "Request failed" });
  } finally {
    res.end();
  }
});
